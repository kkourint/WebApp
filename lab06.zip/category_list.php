<?php
require_once('database.php');

// Get all categories
$query = 'SELECT * FROM categories ORDER BY categoryID';
$statement = $db->prepare($query);
$statement->execute();
$categories = $statement->fetchAll();
$statement->closeCursor();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Working with Data</title>
    <link rel="stylesheet" href="main.css">
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>
<div class="container">
<header><h1>Product Manager</h1></header>
<main>
    <h1>Category List</h1>
    <!-- add code for the table here -->
    
    <h2>Add Category</h2>
    
    <!-- add code for the form here -->
    
    <br>
    <p><a href="index.php">List Products</a></p>
    </main>
    <footer>
    </footer>
</div>
</body>
</html>